# Configuración del Proyecto Pedro

## Estado
- Fecha de inicio: 2026-04-03
- Estado: Análisis completo — listo para desarrollar

## Descripción
Negocio de sublimación/impresión personalizada. Sistema de gestión financiera y ventas con dashboard web.

## URLs del proyecto
| Servicio | URL |
|---|---|
| App (Finanzas-Nexos) | https://dtar-01pedro.oj16f5.easypanel.host/ |
| n8n workflow | https://dtar-n8n.oj16f5.easypanel.host/workflow/OpWSnO3z0YmP1wot |
| Google Sheets | https://docs.google.com/spreadsheets/d/1g8lR3i_ex5scINzYoUA_hHM2ImaQ4Tg642MOTVvJ77Y |
| GitHub | https://github.com/abelitodtar1-eng/ |

## Repositorio principal
- **FinanzasPedro** — https://github.com/abelitodtar1-eng/FinanzasPedro
- Stack: Node.js/Express + HTML/JS + Python + Docker
- Fuente de datos: Google Sheets API (mismo spreadsheet compartido)
- Config: `variables_n8n.json` (productos, precios, tasas, salarios)

## Arquitectura actual
- `server.js` — Express, expone 4 endpoints: `/api/hoy`, `/api/semana`, `/api/mes`, `/api/catalogo`
- `dashboard.html` — Frontend vanilla JS + Chart.js
- `variables_n8n.json` — Configuración de productos, precios, tasas USD/MLC
- `main.py` — Integración OpenRouter para análisis con IA
- Google Sheets ID: `1g8lR3i_ex5scINzYoUA_hHM2ImaQ4Tg642MOTVvJ77Y`

## Configuración de negocio
- Tasas: USD = 515 CUP, MLC = 400 CUP
- Empleadas: Danay y Dayan (salario 640.9 c/u)
- Métodos de pago: Transferencia, Sin Pago, Efectivo
- 41 productos catalogados

## Resumen semanal (referencia)
- Inversión total: 39,686.07 CUP
- Ventas totales: 64,800.00 CUP
- Ganancia neta: 20,091.14 CUP

## Estructura de carpetas local
- `01.config/` — Configuraciones del proyecto
- `02.historial/` — Historial de conversaciones y decisiones
